#pragma once


#include <QDialog>
#include "ui_QtModelSet.h"
#include <QTreeWidgetItem>
#include <QTreeWidget>
#include <QSpinBox>
#include <QLineEdit>
#include <QTextEdit>
#include <qcombobox>
#include "Machine.h"
#include "../MSerialsCommon/common.h"

class QSlider;


class QtModelSet : public QDialog
{
	Q_OBJECT

public:
	QtModelSet(QWidget *parent = Q_NULLPTR);
	~QtModelSet();

	bool isParaChanged = false;

	void UpDataUI();

	void InitUI();

	void InitWidgets();

	void InitWidget();

	void initSetParamsControl();

	void Line_Settings();

	void Line1_Settings();

	void Line2_Settings();

	void ConnetSlot();
	void OnInitDialog();
	void closeEvent(QCloseEvent * ev);
private:
	

	Ui::QtModelSet ui;
	//
	QGridLayout *pGridLayout;
	///<��Ƶwidget
	QTabWidget	*tabWidget;

	QSlider *slider;
	


	//��·һ��tab����
	QTabWidget	*tabWidget_Set_Line;
	//��·����tab����
	QTabWidget	*tabWidget_Set_Line1;
	//��·����tab����
	QTabWidget	*tabWidget_Set_Line2;

	QScrollArea *scrollArea;
	QScrollArea *scrollArea1;
	QScrollArea *scrollArea2;
	///<��·1��ʾͼƬ
	QLabel	*label;
	QPushButton *Button_Show_Model;
	QPushButton *Button_Show_Online;
	QPushButton *Button_Set_As_Model;
	QPushButton *Button_Set_As_Draw;































	QLabel	*label1;
	QPushButton *Button_Show_Model1;
	QPushButton *Button_Show_Online1;
	QPushButton *Button_Set_As_Model1;

	QLabel *label2;
	QPushButton *Button_Show_Model2;
	QPushButton *Button_Show_Online2;
	QPushButton *Button_Set_As_Model2;
	///<��������widget
	QScrollArea *ParaWidget;
	QTabWidget *tabWidget1;

	///<�·���ⰴť
	QPushButton *Button_One_Key_Detect;
	QPushButton *Button_Save_Current_Line_Model;
	QPushButton *Button_Save_Model;
	QPushButton *Button_Quit;
	QPushButton *Button_Load_Current_Model;
	QPushButton *Button_Model_List;
	//����ͼ�������
	QLabel *label_brower;


public slots:
	void bianxingjianceChanged();
	void silakoupingbi();

	void ChangeList(int);

	void _Button_Show_Model();
	void setValue(int a);
	//��·1��ʾͼƬ����Ч��
	void _Show_Online_Effect();
	//��·1��ť��ʾͼƬ
	void _Button_Show_Online();
	//��·1����ģ��
	void _Button_Set_As_Model();
	

	void _Button_Show_Model1();
	//��·2��ʾͼƬ����Ч��
	void _Show_Online_Effect1();

	void _Button_Show_Online1();
	void _Button_Set_As_Model1();

	void _Button_Show_Model2();
	//��·3��ʾͼƬ����Ч��
	void _Show_Online_Effect2();

	void _Button_Show_Online2();
	void _Button_Set_As_Model2();
	///<��������widget

	///<�·���ⰴť
	void _Button_One_Key_Detect();
	void _Button_Save_Current_Line_Model();
	void _Button_Save_Model();
	void _Button_Quit();
	void _Button_Load_Current_Model();
	void _Button_Model_List();









private:
	std::vector<QScrollArea*> m_vec_scrollArea;
	//ÿ���������һ��disp_hand
	std::vector<Halcon::HTuple> m_disp_hd;
	std::vector<Halcon::Hobject> m_disp_image;

	HANDLE hThread[MAX_DEVICE_NUM];
	//��ֹ�߳�
	int hThreadExit[MAX_DEVICE_NUM];





	//��һ·����������
	QTreeWidgetItem * root_item_line1_checking_params_setting = nullptr;
	QTreeWidget		* pTreeWidget_line1_checking_params_stting = nullptr;
	//���μ�⣬root
	QTreeWidgetItem * root_item_shape = nullptr;
	

	

	//ƿ��Բ�� ָ����

	//ƿ�ڱ��ζ�

	//��͹����

	//�ڰ�����

	//�̱�ƥ���

	//��·1���ò����б�

	//���μ�⣬�����ر�
	QComboBox*	pComboBox_bianxingjiance = nullptr;
	QTreeWidgetItem* child_silakou = nullptr;

	//˺�������Σ������ر�
	QComboBox* pComboBox_silakoupingbi = nullptr;

	QTreeWidgetItem* child_pingkouyuandu = nullptr;
	QLineEdit* LE_pingkouyuandu = nullptr;

	QTreeWidgetItem* child_pingkoubianxingdu = nullptr;
	QLineEdit *LE_pingkoubianxingdu = nullptr;

	QTreeWidgetItem* child_waitujuli = nullptr;
	QLineEdit *LE_waitujuli = nullptr;

	QTreeWidgetItem* child_neiaojuli = nullptr;
	QLineEdit *LE_neiaojuli = nullptr;


	QTreeWidgetItem* child_shangbiaopipei = nullptr;

	QTreeWidgetItem* child_baiyisedian = nullptr;

	QTreeWidgetItem* child_secha = nullptr;

	QTreeWidgetItem* child_mianji = nullptr;

	QTreeWidgetItem* child_huangban = nullptr;

	QTreeWidgetItem* child_xiaoaokeng = nullptr;

	QComboBox* pComboBox_dingaojiance = nullptr;
	QTreeWidgetItem* child_dingaosecha = nullptr;
	QSlider* slider_dingaosecha = nullptr;

	QComboBox* pComboBox_chuancijiance = nullptr;

	QTreeWidgetItem * root_item_line1_model_params_setting = nullptr;

};
