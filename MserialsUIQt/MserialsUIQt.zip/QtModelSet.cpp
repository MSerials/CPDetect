#include "stdafx.h"
#include "QtModelSet.h"
#include "Ini.h"
#include "../../../MSerialsCore/Tools/Tools.h"
#include "ImageMgr.h"
#include "Common.h"
#include "global.h"
//#include <thread.h>
//C++11 ��׼�����̣߳�Ŀ����Ϊ��linux��windows����ͳһ
#include <thread>
#include <Windows.h>
#include <QListWidget>
#include "QuitTipDlg.h"


QtModelSet::QtModelSet(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
	resize(1024, 768);
	pGridLayout = nullptr;
	tabWidget = nullptr;
	tabWidget1 = nullptr;
	InitUI();
	ConnetSlot();

}

QtModelSet::~QtModelSet()
{
}


void QtModelSet::UpDataUI()
{

}

void QtModelSet::InitUI()
{
	if (nullptr == pGridLayout) pGridLayout = new QGridLayout(this);
	InitWidget();
	initSetParamsControl();
}

//new ��widget����ʾ
void QtModelSet::InitWidgets()
{

}


//old ��scroll����ʾ
void QtModelSet::InitWidget()
{
	//�����������ͼ��
	if (nullptr == tabWidget)
	{
		tabWidget = new QTabWidget(this);

		//����һ��widget���ⲿ��grid����
		static QWidget *widget = new QWidget(this);
		static QGridLayout *gridLayout = new QGridLayout(widget);
		label = new QLabel(this);
		scrollArea = new QScrollArea(this);
		scrollArea->setBackgroundRole(QPalette::Dark);
		scrollArea->setWidget(label);
		scrollArea->setAlignment(Qt::AlignCenter);
		gridLayout->addWidget(scrollArea, 0, 0, 4, 6);
		Button_Show_Model = new QPushButton(QString::fromLocal8Bit("��ʾģ��ͼ��"));
		gridLayout->addWidget(Button_Show_Model, 6, 0, 1, 1);
		Button_Show_Online = new QPushButton(QString::fromLocal8Bit("��ʾ����ͼ��"));
		gridLayout->addWidget(Button_Show_Online, 6, 2, 1, 1);
		Button_Set_As_Model = new QPushButton(QString::fromLocal8Bit("��Ϊģ��ͼ��"));
		gridLayout->addWidget(Button_Set_As_Model, 6, 4, 1, 1);
		tabWidget->addTab(widget, QString::fromLocal8Bit("��·1"));

		static QWidget *widget1 = new QWidget(this);
		static QGridLayout *gridLayout1 = new QGridLayout(widget1);
		label1 = new QLabel(this);
		scrollArea1 = new QScrollArea(this);
		scrollArea1->setBackgroundRole(QPalette::Dark);
		scrollArea1->setWidget(label1);
		scrollArea1->setAlignment(Qt::AlignCenter);
		gridLayout1->addWidget(scrollArea1, 0, 0, 4, 6);
		Button_Show_Model1 = new QPushButton(QString::fromLocal8Bit("��ʾģ��ͼ��"));
		gridLayout1->addWidget(Button_Show_Model1, 6, 0, 1, 1);
		Button_Show_Online1 = new QPushButton(QString::fromLocal8Bit("��ʾ����ͼ��"));
		gridLayout1->addWidget(Button_Show_Online1, 6, 2, 1, 1);
		Button_Set_As_Model1 = new QPushButton(QString::fromLocal8Bit("��Ϊģ��ͼ��"));
		gridLayout1->addWidget(Button_Set_As_Model1, 6, 4, 1, 1);
		tabWidget->addTab(widget1, QString::fromLocal8Bit("��·2"));

		static QWidget *widget2 = new QWidget(this);
		static QGridLayout *gridLayout2 = new QGridLayout(widget2);
		label2 = new QLabel(this);
		scrollArea2 = new QScrollArea(this);
		scrollArea2->setBackgroundRole(QPalette::Dark);
		scrollArea2->setWidget(label2);
		scrollArea2->setAlignment(Qt::AlignCenter);
		gridLayout2->addWidget(scrollArea2, 0, 0, 4, 6);
		Button_Show_Model2 = new QPushButton(QString::fromLocal8Bit("��ʾģ��ͼ��"));
		gridLayout2->addWidget(Button_Show_Model2, 6, 0, 1, 1);
		Button_Show_Online2 = new QPushButton(QString::fromLocal8Bit("��ʾ����ͼ��"));
		gridLayout2->addWidget(Button_Show_Online2, 6, 2, 1, 1);
		Button_Set_As_Model2 = new QPushButton(QString::fromLocal8Bit("��Ϊģ��ͼ��"));
		gridLayout2->addWidget(Button_Set_As_Model2, 6, 4, 1, 1);
		tabWidget->addTab(widget2, QString::fromLocal8Bit("��·3"));

		pGridLayout->addWidget(tabWidget,1, 0, 7, 6);
	}



	//�ڶ������棬
	ParaWidget = new QScrollArea(this);
	pGridLayout->addWidget(ParaWidget, 0, 6, 13, 4);
	/**
	if (nullptr == tabWidget1)
	{
		tabWidget1 = new QTabWidget(this);
		pGridLayout->addWidget(tabWidget1, 0, 6, 13, 4);
	}  
	*/


	//�·���ⰴť
	{
		Button_One_Key_Detect = new QPushButton(QString::fromLocal8Bit("һ�����"));
		pGridLayout->addWidget(Button_One_Key_Detect, 13, 2, 1, 1);

		Button_Save_Current_Line_Model = new QPushButton(QString::fromLocal8Bit("���浱ǰ·ģ��"));
		pGridLayout->addWidget(Button_Save_Current_Line_Model, 13, 3, 1, 2);

		Button_Save_Model = new QPushButton(QString::fromLocal8Bit("����ģ��"));
		pGridLayout->addWidget(Button_Save_Model, 13, 5, 1, 1);

		Button_Quit = new QPushButton(QString::fromLocal8Bit("�˳�"));
		pGridLayout->addWidget(Button_Quit, 13, 6, 1, 1);

		Button_Load_Current_Model = new QPushButton(QString::fromLocal8Bit("���ص�ǰģ��"));
		pGridLayout->addWidget(Button_Load_Current_Model, 13, 7, 1, 1);

		Button_Model_List = new QPushButton(QString::fromLocal8Bit("ģ���б�"));
		pGridLayout->addWidget(Button_Model_List, 13, 8, 1, 1);
	}

	//���������汾�������
	{
		static QScrollArea *scrollAreaBrower = new QScrollArea(this);
		label_brower = new QLabel(this);
		scrollAreaBrower->setBackgroundRole(QPalette::Dark);
		scrollAreaBrower->setWidget(label2);
		scrollAreaBrower->setAlignment(Qt::AlignCenter);
		pGridLayout->addWidget(scrollAreaBrower, 10, 12, 3, 3);
	}
	//if
}


void QtModelSet::initSetParamsControl()
{
#define COL_WIDTH 317
#define COL_HEIGHT 720
	//��·һ��tab����
	tabWidget_Set_Line  = new  QTabWidget(ParaWidget);
	tabWidget_Set_Line->resize(COL_WIDTH, COL_HEIGHT);
	//��·����tab����
	tabWidget_Set_Line1 = new  QTabWidget(ParaWidget);
	static QWidget *widget2 = new QWidget(this);
	tabWidget_Set_Line1->addTab(widget2, QString::fromLocal8Bit("��·55"));
	static QWidget *widget3 = new QWidget(this);
	tabWidget_Set_Line1->addTab(widget3, QString::fromLocal8Bit("��·55"));
	//��·����tab����
	tabWidget_Set_Line2 = new  QTabWidget(ParaWidget);

	Line_Settings();
	Line1_Settings();
	Line2_Settings();

	//����������غ���ʾ
	tabWidget_Set_Line1->setHidden(true);
	tabWidget_Set_Line2->setHidden(true);
	tabWidget_Set_Line->setHidden(false);
}

//��·1������
void QtModelSet::Line_Settings()
{
	static QWidget *widget = new QWidget();
	//widget->resize(300, 680);
	pTreeWidget_line1_checking_params_stting = new QTreeWidget(widget);
	pTreeWidget_line1_checking_params_stting->setHeaderLabels(QStringList() << QString::fromLocal8Bit("����") << QString::fromLocal8Bit("ֵ"));

	pTreeWidget_line1_checking_params_stting->setColumnWidth(0,2*COL_WIDTH/3 -10);
	pTreeWidget_line1_checking_params_stting->setColumnWidth(1, COL_WIDTH / 3);

	root_item_line1_checking_params_setting = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("���ǵ��������"));
	pTreeWidget_line1_checking_params_stting->addTopLevelItem(root_item_line1_checking_params_setting);


		//���μ��
		root_item_shape = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("���μ��"));
		root_item_line1_checking_params_setting->addChild(root_item_shape);

		QTreeWidgetItem* child = new QTreeWidgetItem(QStringList()<< QString::fromLocal8Bit("���μ��"));
		root_item_shape->addChild(child);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child, 1, pComboBox_bianxingjiance = new QComboBox);//��QSpinBox��ʾ��child��ĵ�һ����
		pComboBox_bianxingjiance->addItem(QString::fromLocal8Bit("����"));
		pComboBox_bianxingjiance->addItem(QString::fromLocal8Bit("�ر�"));
		if (0 == Preference::GetIns()->prj->para.b_bianxingjiance)
			pComboBox_bianxingjiance->setCurrentIndex(0);
		else
			pComboBox_bianxingjiance->setCurrentIndex(1);
		connect(pComboBox_bianxingjiance, SIGNAL(currentIndexChanged(int)), this, SLOT(bianxingjianceChanged()));

		child_silakou = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("˺��������"));
		root_item_shape->addChild(child_silakou);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_silakou, 1, pComboBox_silakoupingbi = new QComboBox);//��QSpinBox��ʾ��child��ĵ�һ����
		pComboBox_silakoupingbi->addItem(QString::fromLocal8Bit("����"));
		pComboBox_silakoupingbi->addItem(QString::fromLocal8Bit("�ر�"));
		if (0 == Preference::GetIns()->prj->para.b_silakoupingbi)
			pComboBox_silakoupingbi->setCurrentIndex(0);
		else
			pComboBox_silakoupingbi->setCurrentIndex(1);
		connect(pComboBox_silakoupingbi, SIGNAL(currentIndexChanged(int)), this, SLOT(silakoupingbi()));





		child_pingkouyuandu = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("ƿ��Բ��(C)<="));
		root_item_shape->addChild(child_pingkouyuandu);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_pingkouyuandu, 1, LE_pingkouyuandu  = new QLineEdit);//��QSpinBox��ʾ��child��ĵ�һ����

		child_pingkoubianxingdu = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("ƿ�ڱ��ζ�(D0)>="));
		root_item_shape->addChild(child_pingkoubianxingdu);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_pingkoubianxingdu, 1, LE_pingkoubianxingdu = new QLineEdit);//��QSpinBox��ʾ��child��ĵ�һ����

		child_waitujuli = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("��͹����(D1)>="));
		root_item_shape->addChild(child_waitujuli);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_waitujuli, 1, LE_waitujuli = new QLineEdit);//��QSpinBox��ʾ��child��ĵ�һ����

		child_neiaojuli= new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("�ڰ�����(D1)>="));
		root_item_shape->addChild(child_neiaojuli);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_neiaojuli, 1, new QLineEdit);//��QSpinBox��ʾ��child��ĵ�һ����

		child_shangbiaopipei = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("�̱�ƥ���"));
		root_item_shape->addChild(child_shangbiaopipei);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_shangbiaopipei, 1, new QLineEdit);//��QSpinBox��ʾ��child��ĵ�һ����

		QTreeWidgetItem *root_item_white_dots = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("����ɫ����"));
		root_item_line1_checking_params_setting->addChild(root_item_white_dots);

		child_baiyisedian = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("����ɫ����"));
		root_item_white_dots->addChild(child_baiyisedian);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_baiyisedian, 1, new QLineEdit);//��QSpinBox��ʾ��child��ĵ�һ����

		child_secha = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("ɫ��>="));
		root_item_white_dots->addChild(child_secha);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_secha, 1, slider = new QSlider(Qt::Horizontal));//��QSpinBox��ʾ��child��ĵ�һ����
		slider->setMinimum(0);
		slider->setMaximum(255);
		slider->setSingleStep(255);
		connect(slider, SIGNAL(valueChanged(int)), this, SLOT(setValue(int)));
		//connect(pSlider, SIGNAL(valueChanged(int)), pSpinBox, SLOT(setValue(int)));

		child_mianji = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("���(LA)>="));
		root_item_white_dots->addChild(child_mianji);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_mianji, 1, new QLineEdit);//��QSpinBox��ʾ��child��ĵ�һ����

		QTreeWidgetItem *root_item_yellow_spot = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("�ư߼��"));
		root_item_line1_checking_params_setting->addChild(root_item_yellow_spot);

		child_huangban = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("�ư߼��"));
		root_item_yellow_spot->addChild(child_huangban);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_huangban, 1, new QLineEdit);

		child_secha = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("ɫ��>="));
		root_item_yellow_spot->addChild(child_secha);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_secha, 1, new QSlider(Qt::Horizontal));

		child_mianji = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("���(YA)>="));
		root_item_yellow_spot->addChild(child_mianji);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_mianji, 1, new QLineEdit);

		QTreeWidgetItem *root_item_small_pits = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("С���Ӽ��"));
		root_item_line1_checking_params_setting->addChild(root_item_small_pits);

		child_xiaoaokeng = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("С���Ӽ��"));
		root_item_small_pits->addChild(child_xiaoaokeng);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_xiaoaokeng, 1, new QLineEdit);

		child_secha = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("ɫ��>="));
		root_item_small_pits->addChild(child_secha);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_secha, 1, new QSlider(Qt::Horizontal));

		child_mianji = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("���(PA)>="));
		root_item_small_pits->addChild(child_mianji);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_mianji, 1, new QLineEdit);

		//�������ݼ���б�
		QTreeWidgetItem *root_dingbuaokengjiance = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("�������ݼ��"));
		root_item_line1_checking_params_setting->addChild(root_dingbuaokengjiance);

		QTreeWidgetItem *child_dingaojiance = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("�������"));
		root_dingbuaokengjiance->addChild(child_dingaojiance);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_dingaojiance, 1, pComboBox_dingaojiance = new QComboBox);
		pComboBox_dingaojiance->addItem(QString::fromLocal8Bit("����"));
		pComboBox_dingaojiance->addItem(QString::fromLocal8Bit("�ر�"));
		if (0 == Preference::GetIns()->prj->para.b_dingaojiance)
			pComboBox_dingaojiance->setCurrentIndex(0);
		else
			pComboBox_dingaojiance->setCurrentIndex(1);
		connect(pComboBox_dingaojiance, SIGNAL(currentIndexChanged(int)), this, SLOT(dingaojianceChanged()));


		child_dingaosecha = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("ɫ��>="));
		root_dingbuaokengjiance->addChild(child_dingaosecha);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_dingaosecha, 1, slider_dingaosecha = new QSlider(Qt::Horizontal));
		connect(slider_dingaosecha, SIGNAL(valueChanged(int)), this, SLOT(dingaosechaChanged(int)));

		//���̼���б�
		QTreeWidgetItem *root_chuancijiance = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("���̼��"));
		root_item_line1_checking_params_setting->addChild(root_chuancijiance);

		QTreeWidgetItem *child_chuancijiance = new QTreeWidgetItem(QStringList() << QString::fromLocal8Bit("���̼��"));
		root_chuancijiance->addChild(child_chuancijiance);
		pTreeWidget_line1_checking_params_stting->setItemWidget(child_chuancijiance, 1, pComboBox_chuancijiance = new QComboBox);
		pComboBox_chuancijiance->addItem(QString::fromLocal8Bit("����"));
		pComboBox_chuancijiance->addItem(QString::fromLocal8Bit("�ر�"));
		if (0 == Preference::GetIns()->prj->para.b_chuancijiance)
			pComboBox_chuancijiance->setCurrentIndex(0);
		else
			pComboBox_chuancijiance->setCurrentIndex(1);
		connect(pComboBox_chuancijiance, SIGNAL(currentIndexChanged(int)), this, SLOT(chuancijianceChanged()));


		
		                                                                                                                                                                                                                                                                       



	tabWidget_Set_Line->addTab(pTreeWidget_line1_checking_params_stting, QString::fromLocal8Bit("����������"));




	
	//static QTableWidget *tableWidget = new QTableWidget(widget);
	/* ���� Id Name �ֶε�ֵ�����޸� */
	/* ���ò����޸ĵ�Id Name���еı�����ɫΪ��ɫ */
	
//	
	//pTreeWidget_line1_checking_params_stting->addTopLevelItem(root_item_line1_checking_params_setting);
	











	/**

	int NumOfReg = 2;
	for (int i = 0; i < NumOfReg; i++) {
		QTableWidgetItem *item = new QTableWidgetItem();
		item->setBackground(QBrush(QColor(Qt::lightGray)));
		item->setFlags(item->flags() & (~Qt::ItemIsEditable));
		tableWidget->setItem(i, 0, item);
	}
	for (int i = 0; i < NumOfReg; i++) {
		QTableWidgetItem *item = new QTableWidgetItem();
		item->setBackground(QBrush(QColor(Qt::lightGray)));
		item->setFlags(item->flags() & (~Qt::ItemIsEditable));
		tableWidget->setItem(i, 1, item);
	}
	*/

	static QWidget *widget1 = new QWidget(this);
	tabWidget_Set_Line->addTab(widget1, QString::fromLocal8Bit("ģ���������"));
}

void QtModelSet::bianxingjianceChanged()
{
	isParaChanged = true;
	int value = pComboBox_bianxingjiance->currentIndex();
	if (value == 0)
	{
		//����                                                                                                                               
		Preference::GetIns()->prj->para_bak.b_bianxingjiance = 0;
		child_pingkouyuandu->setDisabled(false);
		LE_pingkouyuandu->setDisabled(false);

		child_pingkoubianxingdu->setDisabled(false);
		LE_pingkoubianxingdu->setDisabled(false);

		child_waitujuli->setDisabled(false);
		LE_waitujuli->setDisabled(false);

		child_neiaojuli->setDisabled(false);
		child_shangbiaopipei->setDisabled(false);
	}
	else
	{
		//�ر�
		Preference::GetIns()->prj->para_bak.b_bianxingjiance = 1;
		child_pingkouyuandu->setDisabled(true);
		LE_pingkouyuandu->setDisabled(true);

		child_pingkoubianxingdu->setDisabled(true);
		LE_pingkoubianxingdu->setDisabled(true);

		child_waitujuli->setDisabled(true);
		LE_waitujuli->setDisabled(true);

		child_neiaojuli->setDisabled(true);
		child_shangbiaopipei->setDisabled(true);
	}


}

void QtModelSet::silakoupingbi() {
	isParaChanged = true;
	int value =  pComboBox_bianxingjiance->currentIndex();
	if (value == 0)
	{
		Preference::GetIns()->prj->para_bak.b_silakoupingbi = 0;
	}
	else
	{
		Preference::GetIns()->prj->para_bak.b_silakoupingbi = 1;
	}
}

//��·2������
void QtModelSet::Line1_Settings()
{
}

//��·3������
void QtModelSet::Line2_Settings()
{
}

void QtModelSet::ConnetSlot()
{
	connect(tabWidget, SIGNAL(currentChanged(int)), this, SLOT(ChangeList(int)));
	connect(Button_Show_Model, SIGNAL(clicked()), this, SLOT(_Button_Show_Model()));
	connect(Button_Show_Online, SIGNAL(clicked()), this, SLOT(_Button_Show_Online()));
	connect(Button_Set_As_Model, SIGNAL(clicked()), this, SLOT(_Button_Set_As_Model()));
	connect(Button_Show_Model1, SIGNAL(clicked()), this, SLOT(_Button_Show_Model1()));
	connect(Button_Show_Online1, SIGNAL(clicked()), this, SLOT(_Button_Show_Online1()));
	connect(Button_Set_As_Model1, SIGNAL(clicked()), this, SLOT(_Button_Set_As_Model1()));
	connect(Button_Show_Model2, SIGNAL(clicked()), this, SLOT(_Button_Show_Model2()));
	connect(Button_Show_Online2, SIGNAL(clicked()), this, SLOT(_Button_Show_Online2()));
	connect(Button_Set_As_Model2, SIGNAL(clicked()), this, SLOT(_Button_Set_As_Model2()));
	connect(Button_One_Key_Detect, SIGNAL(clicked()), this, SLOT(_Button_One_Key_Detect()));
	connect(Button_Save_Current_Line_Model, SIGNAL(clicked()), this, SLOT(_Button_Save_Current_Line_Model()));
	connect(Button_Save_Model, SIGNAL(clicked()), this, SLOT(_Button_Save_Model()));
	connect(Button_Quit, SIGNAL(clicked()), this, SLOT(_Button_Quit()));
	connect(Button_Load_Current_Model, SIGNAL(clicked()), this, SLOT(_Button_Load_Current_Model()));
	connect(Button_Model_List, SIGNAL(clicked()), this, SLOT(_Button_Model_List()));
}

//�����widget��ʱ����������б�
void QtModelSet::ChangeList(int selected)
{
	switch (selected)
	{
	case 0:
		tabWidget_Set_Line1->setHidden(true);
		tabWidget_Set_Line2->setHidden(true);
		tabWidget_Set_Line->setHidden(false); break;
	case 1:
		tabWidget_Set_Line1->setHidden(false);
		tabWidget_Set_Line2->setHidden(true);
		tabWidget_Set_Line->setHidden(true); break;
	case 2:
		tabWidget_Set_Line1->setHidden(true);
		tabWidget_Set_Line2->setHidden(false);
		tabWidget_Set_Line->setHidden(true); break;
	default:break;
	}
}

void QtModelSet::_Button_Show_Model()
{

//	QMessageBox::information(NULL, tr("Path"), tr("You didn't select any files."));
}

void QtModelSet::setValue(int a){
	isParaChanged = true;
	using namespace Halcon;
	Hobject  Image, Regions, Red, Green, Blue, Hue, inner, ConnectedRegions, MaxArea;
	Hobject  Saturation, Intensity, Saturated, ContoursSplit;
	Hobject  SortedContours, ObjectSelected;
	try {
		set_check("~give_error");
		set_draw(m_disp_hd.at(0), "fill");
		set_color(m_disp_hd.at(0),"red");
		Halcon::Hobject hobj, GrayImage;


		Halcon::decompose3(m_disp_image.at(0), &Red, &Green, &Blue);
		trans_from_rgb(Red, Green, Blue, &Hue, &Saturation, &Intensity, "hsv");
		threshold(Saturation, &inner, a, 255);
		h_disp_obj(m_disp_image.at(0), m_disp_hd.at(0));
		h_disp_obj(inner, m_disp_hd.at(0));

		/**
		rgb1_to_gray(m_disp_image.at(0), &GrayImage);

		Halcon::threshold(GrayImage,&hobj,0,double(a));

		h_disp_obj(m_disp_image.at(0), m_disp_hd.at(0));
		h_disp_obj(hobj, m_disp_hd.at(0));
		*/

		Preference::GetIns()->prj->para_bak.threshold_back_cap = a;
		std::cout << "value:" << a << std::endl;
	}
	catch (Halcon::HException e)
	{
		std::cout << "error" << std::endl;
	}
	catch (std::out_of_range e) {
		std::cout << e.what() << std::endl;
	}
}


void QtModelSet::_Show_Online_Effect() {

}

void QtModelSet::_Button_Show_Online()
{

	Machine::GetIns()->m_mc->Write_Output_Ex(0, OUT_CAM1, 1);
	try {
		Halcon::set_check("~give_error");
		//����ֵ����⣬�����غ��½��ض��ܹ������ع⣿��������
		Sleep(1);
		SnapHobj(m_disp_image.at(0), 0, 0, 10);
		h_disp_obj(m_disp_image.at(0), m_disp_hd.at(0));
	}
	catch (Halcon::HException e)
	{
		std::cout << "failed to capture" << std::endl;
	}
	catch (std::out_of_range out)
	{
		std::cout << out.what() << std::endl;
	}
	Machine::GetIns()->m_mc->Write_Output_Ex(0, OUT_CAM1, 0);
}

void QtModelSet::_Button_Set_As_Model()
{
	QString image_path = Preference::GetIns()->sys->para.Project_Name + "/line1";
	QDir dir(image_path);
	if (!dir.exists())
	{
		QDir d; d.mkdir(image_path);
		std::cout <<" making " <<image_path.toLatin1().data() << " directory"<< std::endl;
	}
	
	try {
		Halcon::set_check("~give_error");
		MSerials::Tools::h_write_image(m_disp_image.at(0),image_path.toLatin1().data());
	}
	catch (Halcon::HException he)
	{
		std::cout << "can not save image" << std::endl;
	}
	return;

	QString path = QFileDialog::getOpenFileName(this, tr("Open Image"), ".", tr("Image Files(*.bmp *.jpg *.jpeg *.png *.gif *.tiff)"));
	if (path.length() == 0) return;
	QByteArray ba = path.toLocal8Bit();
	Halcon::Hobject image;
	Halcon::read_image(&image, ba.data());
	Machine::GetIns()->h_disp_obj(image, m_disp_hd.at(0));
}

void QtModelSet::_Button_Show_Model1()
{
}

void QtModelSet::_Show_Online_Effect1()
{
}

void QtModelSet::_Button_Show_Online1()
{
	Machine::GetIns()->m_mc->Write_Output_Ex(0, OUT_CAM2, 1);
	try {
		Halcon::set_check("~give_error");
		Sleep(1);
		SnapHobj(m_disp_image.at(1), 0, 1, 10);
		h_disp_obj(m_disp_image.at(1), m_disp_hd.at(1));
	}
	catch (Halcon::HException e)
	{
		Halcon::set_tposition(m_disp_hd.at(1),1,1);
		Halcon::write_string(m_disp_hd.at(1),"no image");
		std::cout << "failed to capture" << std::endl;
	}
	catch (std::out_of_range out)
	{
		std::cout << out.what() << std::endl;
	}
	Machine::GetIns()->m_mc->Write_Output_Ex(0, OUT_CAM2, 0);

}

void QtModelSet::_Button_Set_As_Model1()
{
	//����ڶ�·��ͼ��
	QString image_path = Preference::GetIns()->sys->para.Project_Name + "/line2cam2";
	QDir dir(image_path);
	if (!dir.exists())
	{
		QDir d; d.mkdir(image_path);
		std::cout << " making " << image_path.toLatin1().data() << " directory" << std::endl;
	}

	try {
		Halcon::set_check("~give_error");
		MSerials::Tools::h_write_image(m_disp_image.at(1), image_path.toLatin1().data());
	}
	catch (Halcon::HException he)
	{
		std::cout << "can not save image" << std::endl;
	}
}

void QtModelSet::_Button_Show_Model2()
{
	QString path = QFileDialog::getOpenFileName(this, tr("Open Image"), ".", tr("Image Files(*.bmp *.jpg *.jpeg *.png *.gif *.tiff)"));
	if (path.length() == 0) return;

	QByteArray ba = path.toLocal8Bit();

	Halcon::Hobject image;
	Halcon::read_image(&image, ba.data());
	Machine::GetIns()->h_disp_obj(image, m_disp_hd.at(2));
}

void QtModelSet::_Show_Online_Effect2()
{
}

void QtModelSet::_Button_Show_Online2()
{
}

void QtModelSet::_Button_Set_As_Model2()
{
#define POS_DETECT_COLOR 2
	using namespace Halcon;
	if (Machine::NO_RECT != Machine::GetIns()->RectInfo)
	{
		QMessageBox::information(NULL, tr("information"), Machine::show_rect_info(Machine::GetIns()->RectInfo));
		return;
	}
#if 0
	EndThread(5);
	Halcon::HTuple  Exception;
	set_check("~give_error");
	try
	{
		Machine::GetIns()->RectInfo = Machine::CRICLE;
		double row, col, radius;
		Hobject ROI;
		Halcon::set_color(m_disp_hd[POS_DETECT_COLOR], "green");
		set_draw(m_disp_hd[POS_DETECT_COLOR], "margin");
		draw_circle(m_disp_hd[POS_DETECT_COLOR], &row, &col, &radius);
		gen_circle(&ROI, row, col, radius);
		disp_obj(ROI, m_disp_hd[POS_DETECT_COLOR]);
		Preference::GetIns()->prj->Color_Circle.r = row;
		Preference::GetIns()->prj->Color_Circle.c = col;
		Preference::GetIns()->prj->Color_Circle.radius = radius;
		Preference::GetIns()->prj->WriteSettings(PARA_IMAGE);
		Machine::GetIns()->RectInfo = Machine::NO_RECT;
	}
	catch (HException except)
	{
		write_string(m_disp_hd[POS_DETECT_COLOR], except.message);
	}
#endif
}


void QtModelSet::_Button_One_Key_Detect()
{
	//һ�����
	try {
		clock_t tick = clock();
		Machine::GetIns()->back_cap_detect(m_disp_image.at(0), m_disp_hd.at(0), Preference::GetIns()->prj->para);
		std::cout << "cost first camera time is " << (clock() - tick) << " ms" << std::endl;
	}
	catch (std::out_of_range e)
	{
		std::cout << e.what() << std::endl;
	}
}

void QtModelSet::_Button_Save_Current_Line_Model()
{
}

void QtModelSet::_Button_Save_Model()
{
}

void QtModelSet::_Button_Quit()
{
}

void QtModelSet::_Button_Load_Current_Model()
{
}

void QtModelSet::_Button_Model_List()
{
}



//��ʼ������
void QtModelSet::OnInitDialog()
{
	m_vec_scrollArea.push_back(scrollArea);
	m_vec_scrollArea.push_back(scrollArea1);
	m_vec_scrollArea.push_back(scrollArea2);
	Halcon::set_check("give_error");
	for (size_t i = 0; i < m_vec_scrollArea.size(); i++){
		HTuple disp_hand;
		Halcon::set_check("~father");
		Halcon::open_window(0,0,m_vec_scrollArea[0]->width(), m_vec_scrollArea[0]->height(),(Hlong)m_vec_scrollArea[i]->winId(),"visible","",&disp_hand);
		m_disp_hd.push_back(disp_hand);

	}	
	for (int i = 0; i < MAX_CAM; i++){
		Hobject a;
		m_disp_image.push_back(a);
	}
}

//�رհ�ť����ѡ��
void QtModelSet::closeEvent(QCloseEvent *ev)
{
	if (isParaChanged != true) {
		ev->accept();
		return;
	}
	QuitTipDlg QtMDlg;
	QtMDlg.exec();
	int res = QtMDlg.Sel();
	switch (res) {
	case QuitTipDlg::CANCEL:ev->ignore();break;
	case QuitTipDlg::QUIT:ev->accept(); break;
	case QuitTipDlg::QUITANDSAVE:
		//���в�������
		Preference::GetIns()->prj->para = Preference::GetIns()->prj->para_bak;
		Preference::GetIns()->prj->WriteSettings();
		ev->accept();
		break;
	default:ev->ignore(); break;
	}
}
